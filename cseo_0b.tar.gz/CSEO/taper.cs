using System;

namespace dotNet 
{

public static class Taper 
{
	public static string load (this Wise w, string config){return "";}
	public static void save (this Wise w, string config){}
	public static string read (this Wise w, string filename){return "";}
	public static void write (this Wise w, string filename){}

}

}
