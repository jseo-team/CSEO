using System;

namespace dotNet
{

public static class WiseCPP
{
	public static void UCC(this Wise w, string cpp){}
	
}

}
