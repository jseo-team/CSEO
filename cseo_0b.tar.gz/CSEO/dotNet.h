//todo :
//import assembly JSEO.csharp
// define JS methods csharp.CSEO
// and csharp.eval
// export module csharp

