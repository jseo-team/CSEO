# JSEO
javascript entrypoint oriented
