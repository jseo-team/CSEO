//todo : export to JS
// string dotNet.CSEO(string);
// string dotNet.eval(string);
